<footer class="footer">&copy; 2023 Finsta</footer>
</div>
</body>
</html>